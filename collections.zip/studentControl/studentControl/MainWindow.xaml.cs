﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace studentControl
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public static List<Student> A201students = new List<Student>()
        {

        new Student()
        {
            Name = "Ivan",
            Surname = "Komarov",
            Age = 21,
            group = A201
        },
        new Student()
        {
            Name = "Victor",
            Surname = "Kuznecov",
            Age = 19,
            group = A201
        },
        };
       
        
        
        public static Group A201 = new Group() {
            Name = "A201",
            students = A201students
        };

        string chosen;

        public MainWindow()
        {
            InitializeComponent();
            group_cb.Items.Add(A201.Name);



            foreach (TextBlock item in student_group_lb.Items)
            {
                item.AddHandler(UIElement.MouseDownEvent,
   new MouseButtonEventHandler(ListItem_MouseClick), true);

            }

            void ListItem_MouseClick(object sender, MouseEventArgs e)
            {
                TextBlock itemTextBlock = (TextBlock)sender;

chosen = itemTextBlock.Text;

            }




        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void group_cb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (group_cb.SelectedIndex == 0)
            {
                foreach (Student student in A201.students)
                {
                    student_group_lb.Items.Add(student.Name+" "+student.Surname);
                }
            }
        }

        private void act_btn_Click(object sender, RoutedEventArgs e)
        {
            //MessageBox.Show("click");
            switch(act_tabs.SelectedIndex )
            {
                case 0:

                    Student news = new Student();
                    {
                        news.Name = name_tbl.Text;
                        news.Surname = surname_tbl.Text;
                        news.Age = Convert.ToInt32(age_tbl.Text);
                    }

                        A201.students.Add(news);
                        student_group_lb.Items.Add(news.Name + " " + news.Surname);


                    break;

                    case 1:

                    student_group_lb.FocusableChanged += Student_group_lb_FocusableChanged;
                    student_group_lb.SelectionChanged += Student_group_lb_SelectionChanged;




                    foreach (Student student in A201.students)
                    {
                        
                    }

                    break;
            }
        }


        

        private void Student_group_lb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            MessageBox.Show("change");
        }

        private void Student_group_lb_FocusableChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
        }
    }


    

    public class Group
    {
        public String Name { get; set; }
        public List<Student> students { get; set; }
    }

    public class Student
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public int Age { get; set; }
        public Group group { get; set; }
    }
}
