﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.WebSockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            using (ClientWebSocket client = new ClientWebSocket())
            {
                Uri service = new Uri("http://localhost:7096/r/ws");
                var cTs = new CancellationTokenSource();
                cTs.CancelAfter(TimeSpan.FromSeconds(120));
                try
                {
                    await client.ConnectAsync(service, cTs.Token);
                    while (client.State == WebSocketState.Open)
                    {
                        Console.WriteLine("Enter Text");
                        var message = Console.ReadLine();
                        if (!string.IsNullOrEmpty(message))
                        {
                            ArraySegment<byte> byteToSend = new ArraySegment<byte>(Encoding.UTF8.GetBytes(message));
                            await client.SendAsync(byteToSend, WebSocketMessageType.Text, true, cTs.Token);

                            var responseBuffer = new byte[1024];
                            var offset = 0;
                            var packet = 1024;

                            while (true)
                            {
                                ArraySegment<byte> byteReceive = new ArraySegment<byte>(responseBuffer, offset, packet);

                                WebSocketReceiveResult response = await client.ReceiveAsync(byteReceive, cTs.Token);
                                var responseMessage = Encoding.UTF8.GetString(responseBuffer, offset, response.Count);
                                Console.WriteLine(responseMessage);
                            }
                        }
                    }
                }
                catch
                {
                }
            }
        }
    }
}
