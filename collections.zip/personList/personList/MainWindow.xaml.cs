﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Cache;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace personList
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        List<Person> people = new List<Person>() { new Person() {
            Name = "John", Age = 18
            },
                new Person() { Name = "Mike", Age = 21} };



        public MainWindow()
        {
   
            InitializeComponent();
        
        
        foreach (Person human in people)
            {
                peopleLb.Items.Add(human.Name +" "+human.Age);
            }
        
        
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void add_btn_Click(object sender, RoutedEventArgs e)
        {
            Person newp = new Person() { Name = name_txb.Text, Age = Convert.ToInt32(age_txb.Text) };
            people.Add(newp);
            peopleLb.Items.Add(newp.Name + " " + newp.Age);
        }
    }
    public class Person { 
    public String Name { get; set; }
        public int Age { get; set; }
    }

}
